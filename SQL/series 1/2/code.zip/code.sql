-- Section1
   UPDATE stadium SET capacity = capacity - 100;
-- Section2
   UPDATE passenger SET balance = balance + 1000;
-- Section3
   UPDATE passenger SET balance = balance + 300 WHERE name = ("Mahdi");