-- Section1
    select id order_id from orders
	where status =  'warehouse'
	order by id desc;
-- Section2
    select id customer_id, name customer_name  from customers
	where id not in 
	(
		select customer_id from orders
	)
	order by name asc;
-- Section3
	select created_at date, format((sum(status = "canceled")/ count(status))*100,2) cancellation_rate from orders join customers on customers.id = orders.customer_id
	where (is_blocked = 0 or is_blocked is null)
	group by created_at;
    